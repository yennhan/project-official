from flask_socketio import emit,send
from main import socketio


@socketio.on('message')
def handleMessage(msg):
    print('Message'+msg)
    send(msg,broadcast=True)

@socketio.on('my event')
def test_message(message):
    emit('my response', {'data': 'got it!'})
