from flask import Blueprint

main = Blueprint('main', __name__)
dash = Blueprint('dash', __name__)

from . import routes, dashboard, event
