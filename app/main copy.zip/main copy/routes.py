from flask import redirect, url_for, render_template, request
from . import main
import decimal
import boto3,json
from botocore.exceptions import ClientError
from werkzeug.security import check_password_hash
from flask_login import UserMixin, login_user,login_required,logout_user,current_user
from main import login_manager



dynamodb = boto3.resource('dynamodb', region_name="ap-southeast-1")
# Helper class to convert a DynamoDB item to JSON.

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

class User(UserMixin):
    user = dynamodb.Table('CRM-user')

    def __init__(self, user):
        self.id = user

    def __repr__(self):
        return "%d" % (self.id)

@login_manager.user_loader
def load_user(user):
    return User(user)

@main.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@main.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        user = dynamodb.Table('CRM-user')
        email = request.form.get('email')
        password = request.form.get('password')
        try:
            response = user.get_item(
                Key={
                    'user_id': email
                }
            )
        except ClientError as e:
            return "%s" %(e.response['Error']['Message'])
        else:
            try:
               item = response['Item']
            except Exception:
                word="Invalid Username!  ..."
                return render_template('index.html',condition=word)
            else:
                if check_password_hash(item['password'],password):
                    user=User(email)
                    login_user(user)
                    return redirect(url_for('main.dashboard_login'))
                else:
                    word="Wrong Password"
                    return render_template('index.html',condition=word)


@main.route('/dashboard_login')
@login_required
def dashboard_login():
    user = dynamodb.Table('CRM-user')
    response = user.get_item(
        Key={
            'user_id': current_user.id
        }
    )
    item = response['Item']
    name=item['name'][0]
    return render_template('dashboard.html',name=name,username=name)


@login_manager.unauthorized_handler
def unauthorized_handler():
    return 'Unauthorized'

@main.route("/logout")
@login_required
def logout():
    logout_user()
    print('You have been logged out.')
    return redirect(url_for('main.index'))

